from package_oop_9_119 import Cylinder, Complex, Student ,Rectangle

C1 = Complex(20,30)
C1.PrintComplex()

cyl1 = Cylinder(10,10)
cyl1.PrintCylinder()

S1 = Student("Hany Aly", 41, "Associated Professor")
S1.PrintStudent()


w = float(input("Enter width: ",))
l = float(input("Enter lemgth: "))
R1 = Rectangle(w,l)
R1.Display()





